# Massachusetts Library of Things Database

A consolidated, searchable database of "Library of Things" items available through Massachusetts library networks. These programs allow library cardholders to borrow tools, equipment, technology, and other non-traditional items for free.

## 🎯 Project Goal

Library of Things programs are incredible public resources, but discovery is fragmented. Each library maintains its own webpage, making it difficult for patrons to find what's available across a network. This project consolidates that information into searchable databases and interactive apps.

## 📚 Networks Covered

### 1. CWMARS (Central/Western Massachusetts)
- **Region:** Central and Western Massachusetts  
- **Libraries:** 150+ member libraries
- **Status:** ✅ Initial database complete (224 items, 6 libraries with active programs)

### 2. Minuteman Library Network (MLN)
- **Region:** MetroWest Boston
- **Libraries:** 41 member libraries
- **Total LoT Items:** 12,000+ across the network
- **Status:** ✅ Initial database complete (230 verified items, 12 libraries)

## 🔧 Key Finding: Morse Institute Library

**Morse Institute Library in Natick has the most extensive tool lending program in Massachusetts.** Their collection includes:
- Actual power tools (20V Drill Driver, Pressure Washer)
- Complete tool sets (65-piece homeowner's kit, 85-piece socket set)
- Professional measurement equipment (laser measurer, thermal imaging camera)
- Home inspection tools (radon detector, CO meter, electrical test kit)
- 168+ verified items total

## 📁 Project Structure

```
ma-library-of-things/
├── README.md                 # This file
├── data/
│   ├── cwmars_items.json     # CWMARS Library of Things data
│   ├── minuteman_items.json  # Minuteman Network data
│   └── library_contacts.json # Library contact information
├── scripts/
│   ├── generate_xlsx.py      # Generate Excel spreadsheets
│   ├── generate_apps.py      # Generate React apps
│   └── scrape_libraries.py   # Web scraping utilities (future)
├── apps/
│   ├── cwmars_app.jsx        # React app for CWMARS
│   └── minuteman_app.jsx     # React app for Minuteman
├── docs/
│   ├── OUTREACH.md           # Email templates and contacts
│   ├── METHODOLOGY.md        # How data was collected
│   └── CONTRIBUTING.md       # How to add more libraries
└── outputs/
    ├── cwmars_library_of_things.xlsx
    └── minuteman_library_of_things.xlsx
```

## 🚀 Quick Start

### Generate Excel Files
```bash
cd scripts
python generate_xlsx.py --network cwmars
python generate_xlsx.py --network minuteman
```

### View React Apps
The `.jsx` files in `apps/` can be:
1. Uploaded to [Claude.ai](https://claude.ai) as artifacts
2. Integrated into a React project
3. Hosted on platforms like Vercel or Netlify

## 📊 Data Summary

| Network | Verified Items | Libraries | Home/Tool Items | Top Library |
|---------|---------------|-----------|-----------------|-------------|
| CWMARS | 224 | 6 | 45 | Forbes Library |
| Minuteman | 230 | 12 | 85 | Morse Institute |

## 🔗 Live Demos

- **CWMARS App:** [Claude Artifact Link - TBD]
- **CWMARS Spreadsheet:** [Google Sheets Link - TBD]
- **Minuteman App:** [Claude Artifact Link - TBD]
- **Minuteman Spreadsheet:** [Google Sheets Link - TBD]

## 📧 Contact & Outreach

See [docs/OUTREACH.md](docs/OUTREACH.md) for:
- Email templates for contacting libraries
- Verified contact information for library directors
- Status of outreach efforts

## 🤝 Contributing

Want to add more libraries or networks? See [docs/CONTRIBUTING.md](docs/CONTRIBUTING.md).

Key ways to help:
1. **Add data** from libraries not yet included
2. **Verify accuracy** of existing entries
3. **Improve apps** with better search/filter features
4. **Expand coverage** to other Massachusetts networks (SAILS, NOBLE, OCLN, etc.)

## 📜 License

This project is released under the MIT License. The underlying data is publicly available from library websites.

## 🙏 Acknowledgments

- Built with assistance from [Claude AI](https://claude.ai)
- Data sourced from individual library websites
- Inspired by the amazing work of Massachusetts public librarians

---

*Last updated: January 2026*
